package com.calendarapplication.taskcal;

import static com.calendarapplication.taskcal.calUtils.dayinMonthArray;
import static com.calendarapplication.taskcal.calUtils.dayinWeekArray;
import static com.calendarapplication.taskcal.calUtils.monthYearFromDate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.util.ArrayList;

public class WeekActivity extends AppCompatActivity implements calAdapter.OnItemListener
{

    private TextView monthYearText;
    private RecyclerView calendarRecycleView;
    private ListView eventListView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_week);
        initwidgets();
        setWeekView();
    }

    private void setWeekView()
    {
        monthYearText.setText(monthYearFromDate(calUtils.selectedDate));
        ArrayList<LocalDate> days = dayinWeekArray(calUtils.selectedDate);

        calAdapter calAdapter = new calAdapter(days, this);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 7);
        calendarRecycleView.setLayoutManager(layoutManager);
        calendarRecycleView.setAdapter(calAdapter);
        setEventAdapter();

    }


    private void initwidgets()
    {
        calendarRecycleView = findViewById(R.id.calendarRecycleView);
        monthYearText = findViewById(R.id.monthYearTV);
        eventListView = findViewById(R.id.eventListView);


    }

    public void previousWeekAction(View view)
    {
        calUtils.selectedDate = calUtils.selectedDate.minusWeeks(1);
        setWeekView();
    }

    public void nextWeekAction(View view)
    {
        calUtils.selectedDate = calUtils.selectedDate.plusWeeks(1);
        setWeekView();
    }

    @Override
    public void onItemClick(int position, LocalDate date)
    {
            calUtils.selectedDate = date;
            setWeekView();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        setEventAdapter();
    }

    private void setEventAdapter()
    {
        ArrayList<Event> dailyEvents = Event.eventsForDate(calUtils.selectedDate);
        EventAdapter eventAdapter = new EventAdapter(getApplicationContext(), dailyEvents);
        eventListView.setAdapter(eventAdapter);
    }

    public void newEventAction(View view)
    {
        startActivity(new Intent(this, EventEditActivity.class));
    }
}