package com.example.greenbin;



import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Calendar;

public class GpsAdmin extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap gMap;

    Button insertadmin;

    private Button sms;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gps_admin);
        sms=findViewById(R.id.sms);
        sms.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                Intent intent=new Intent(GpsAdmin.this,sms.class);
                startActivity(intent);

            }
        });

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.id_map);
        mapFragment.getMapAsync(this);

        insertadmin = findViewById(R.id.btnInsertt);

    }


    public void onInsertt(View view) {

        Intent intent=new Intent(GpsAdmin.this,insertAdmin.class);
        startActivity(intent);

    }


    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        gMap = googleMap;
        LatLng location = new LatLng(14.5176, 121.0509);
        googleMap.addMarker(new MarkerOptions().position(location).title("Taguig"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12));

        LatLng location1 = new LatLng(14.520269, 121.077974);
        googleMap.addMarker(new MarkerOptions().position(location1).title("Leonel Waste Management"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12));

        LatLng location2 = new LatLng(14.510870, 121.059969);
        googleMap.addMarker(new MarkerOptions().position(location2).title("Construction Debris Hauling"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12));

        LatLng location3 = new LatLng(14.515960, 121.0594008);
        googleMap.addMarker(new MarkerOptions().position(location3).title("Kulitog Junkshop"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12));

        LatLng location4 = new LatLng(14.535239, 121.049821);
        googleMap.addMarker(new MarkerOptions().position(location4).title("E-Waste Zero Bin"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12));

        LatLng location5 = new LatLng(14.546810, 121.053738);
        googleMap.addMarker(new MarkerOptions().position(location5).title("E-Waste Zero Bin"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12));

        LatLng location6 = new LatLng(14.551966, 121.125646);
        googleMap.addMarker(new MarkerOptions().position(location6).title("Trash Dump Collection"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12));

        LatLng location7 = new LatLng(14.573269, 121.093834);
        googleMap.addMarker(new MarkerOptions().position(location7).title("MRBS Garbage Hauling Services"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12));

        LatLng location8 = new LatLng(14.544751, 121.101726);
        googleMap.addMarker(new MarkerOptions().position(location8).title("IPM"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12));
    }


}
