package com.calendarapplication.taskcal;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.time.LocalTime;

public class EventEditActivity extends AppCompatActivity
{
    private EditText eventNm;
    private TextView eventDt, eventTm;

    private LocalTime time;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_edit);
        initwidgets();
        time = LocalTime.now();
        eventTm.setText("Time: " + calUtils.formattedTime(time));
    }

    private void initwidgets()
    {
        eventNm = findViewById(R.id.eventNm);
        eventDt = findViewById(R.id.eventDt);
        eventTm = findViewById(R.id.eventTm);
    }

    public void saveEventAction(View view)
    {
        String eventName = eventNm.getText().toString();
        Event newEvent = new Event(eventName, calUtils.selectedDate, time);
        Event.eventList.add(newEvent);
        finish();
    }
}