package com.example.greenbin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class sms extends AppCompatActivity {

    // initialize variables
    EditText editTextPhone, editTextMessage, editTextLocation, editTextName;
    Button btnSent;
    private int mYear, mMonth, mDay, mHour, mMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms);

        // assign variables
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextMessage = findViewById(R.id.editTextMessage);
        editTextLocation = findViewById(R.id.editTextLocation);
        editTextName = findViewById(R.id.editTextName);
        btnSent = findViewById(R.id.btnSent);

        btnSent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // check condition for permission
                Intent intent = new Intent(sms.this, GpsUser.class);
                startActivity(intent);
                if (ContextCompat.checkSelfPermission(sms.this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED) {
                    // when permission is granted
                    // call the sendSMS method
                    sendSMS();
                } else {
                    // when permission is not granted
                    // request for permission
                    ActivityCompat.requestPermissions(sms.this, new String[]{Manifest.permission.SEND_SMS},
                            10000);
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // check condition
        if (requestCode == 10000 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // permission is granted
            // call the sendSMS method
            sendSMS();
        } else {
            // when permission is denied
            // display toast message
            Toast.makeText(this, "Permission Denied!", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSMS() {
        // Get values from editText
        String phone = editTextPhone.getText().toString();
        String message = editTextMessage.getText().toString();
        String location = editTextLocation.getText().toString();
        String name = editTextName.getText().toString();

        // Check if the strings are empty or not
        if (!phone.isEmpty() && !message.isEmpty() && !location.isEmpty() && !name.isEmpty()) {
            // Construct the full message including location and name
            String fullMessage = "Name: " + name + "\nLocation: " + location + "\nMessage: " + message;

            SmsManager smsManager = SmsManager.getDefault();
            // Send message
            smsManager.sendTextMessage(phone, null, fullMessage, null, null);
            // Display Toast message
            Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_LONG).show();
        } else {
            // When strings are empty, display a toast message
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
        }
    }

    public void onPick(View view) {
        // Get the current date and time
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        // Create and show a DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view1, year, monthOfYear, dayOfMonth) -> {
                    // Update the selected date
                    mYear = year;
                    mMonth = monthOfYear;
                    mDay = dayOfMonth;

                    // Create and show a TimePickerDialog
                    TimePickerDialog timePickerDialog = new TimePickerDialog(
                            this,
                            (view2, hourOfDay, minute) -> {
                                // Update the selected time
                                mHour = hourOfDay;
                                mMinute = minute;

                                // Display the selected date and time
                                String dateTime = String.format("%02d-%02d-%d %02d:%02d", mDay, mMonth + 1, mYear, mHour, mMinute);
                                Toast.makeText(sms.this, "Selected Date and Time: " + dateTime, Toast.LENGTH_SHORT).show();
                            },
                            mHour,
                            mMinute,
                            false
                    );
                    timePickerDialog.show();
                },
                mYear,
                mMonth,
                mDay
        );
        datePickerDialog.show();
    }
}
