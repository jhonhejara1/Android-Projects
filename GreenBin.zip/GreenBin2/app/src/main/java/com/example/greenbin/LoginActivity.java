package com.example.greenbin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.greenbin.databinding.ActivityLogin2Binding;

public class LoginActivity extends AppCompatActivity {

    private ActivityLogin2Binding binding;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLogin2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        try (DatabaseHelper helper = databaseHelper = new DatabaseHelper(this)) {
        }

        binding.loginButton.setOnClickListener(this::onClick);

        binding.signupRedirectText.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
            startActivity(intent);
        });
    }

    private void onClick(View view) {
        String email = binding.loginEmail.getText().toString();
        String password = binding.loginPassword.getText().toString();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(LoginActivity.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
        } else {
            Boolean checkCredentials = databaseHelper.checkEmailPassword(email, password);

            if (checkCredentials) {
                Toast.makeText(LoginActivity.this, "Login Successfully!", Toast.LENGTH_SHORT).show();

                if (email.equals("admin") && password.equals("admin123")) {
                    // Admin login
                    Intent intent = new Intent(LoginActivity.this, GpsAdmin.class);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(LoginActivity.this, GpsUser.class);
                    startActivity(intent);
                }
            } else {
                Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
